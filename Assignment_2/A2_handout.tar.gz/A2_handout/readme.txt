# University of Leeds 2023-24
# COMP 5823M Assignment 2 Flight Simulator

Compile instructions are as for Assignment 2 in Geometric Processing.
